from flask import Flask, render_template, jsonify, request
import json, os, math

app=Flask(__name__)
BASE=os.path.dirname(__file__)
with open(os.path.join(BASE,"static","route_data.json"),encoding="utf-8") as f: DATA=json.load(f)
with open(os.path.join(BASE,"static","manual_network.json"),encoding="utf-8") as f: MANUAL_NETWORK=json.load(f)

# The red hand-marked network is the authoritative navigation network.
# It was extracted from manual-path-network.png, skeletonized, and stored as
# pixel points so the app does not need OpenCV/scikit-image at runtime.
MANUAL_POINTS=[tuple(p) for p in MANUAL_NETWORK["points"]]
MANUAL_INDEX={p:i for i,p in enumerate(MANUAL_POINTS)}

# 8-neighbour graph over the red network skeleton.
MANUAL_GRAPH=[[] for _ in MANUAL_POINTS]
for i,(x,y) in enumerate(MANUAL_POINTS):
    for dx in (-1,0,1):
        for dy in (-1,0,1):
            if dx==0 and dy==0: continue
            j=MANUAL_INDEX.get((x+dx,y+dy))
            if j is not None:
                MANUAL_GRAPH[i].append((j, 1.41421356 if dx and dy else 1.0))

MAP_W=MANUAL_NETWORK["width"]
MAP_H=MANUAL_NETWORK["height"]

# Approximate georeferencing for the supplied KPRIET campus image.
# The campus reference point is based on published KPRIET coordinates; the
# image-to-GPS extent is a prototype calibration and should be refined with
# two or more surveyed campus points for production-grade GPS navigation.
CAMPUS_GPS = {
    "center_lat": 11.076618,
    "center_lon": 77.141945,
    "half_lat": 0.0048,
    "half_lon": 0.0062,
}

def gps_to_map_position(lat, lon):
    """Convert GPS coordinates to the 0-100 campus-map coordinate system."""
    try:
        lat=float(lat); lon=float(lon)
    except (TypeError, ValueError):
        return None
    c=CAMPUS_GPS
    x=50.0 + (lon-c["center_lon"])/c["half_lon"]*50.0
    y=50.0 - (lat-c["center_lat"])/c["half_lat"]*50.0
    # A small margin prevents routing from an unrelated nearby road while
    # still allowing ordinary phone GPS drift at the campus boundary.
    if x < -8 or x > 108 or y < -8 or y > 108:
        return None
    return [round(x,3), round(y,3)]

def nearest_manual_node(position):
    """Return nearest node on the red manually marked network."""
    if not position or len(position)<2:
        return None
    tx=position[0]*MAP_W/100.0
    ty=position[1]*MAP_H/100.0
    # The network is only ~9k nodes, so a direct nearest-node scan is fast.
    best_i=0; best_d=float("inf")
    for i,(x,y) in enumerate(MANUAL_POINTS):
        d=(x-tx)*(x-tx)+(y-ty)*(y-ty)
        if d<best_d:
            best_d=d; best_i=i
    return best_i

def manual_route(start_pos,end_pos):
    """Shortest walkable path constrained strictly to the red manual network."""
    s=nearest_manual_node(start_pos); t=nearest_manual_node(end_pos)
    if s is None or t is None: return []
    import heapq
    pq=[(0.0,s)]; dist={s:0.0}; prev={}
    while pq:
        cost,u=heapq.heappop(pq)
        if cost!=dist.get(u): continue
        if u==t: break
        for v,w in MANUAL_GRAPH[u]:
            nc=cost+w
            if nc<dist.get(v,float("inf")):
                dist[v]=nc; prev[v]=u; heapq.heappush(pq,(nc,v))
    if t not in dist: return []
    ids=[]; u=t
    while True:
        ids.append(u)
        if u==s: break
        u=prev[u]
    ids.reverse()
    # Convert pixel coordinates to the SVG's 0-100 coordinate system.
    return [[round(MANUAL_POINTS[i][0]/MAP_W*100,3), round(MANUAL_POINTS[i][1]/MAP_H*100,3)] for i in ids]

def simplify_polyline(points, epsilon=1.25):
    """Ramer-Douglas-Peucker simplification while keeping the route on the marked line."""
    if len(points)<=2: return points
    def dist_point_line(p,a,b):
        x,y=p; x1,y1=a; x2,y2=b
        dx=x2-x1; dy=y2-y1
        if dx==0 and dy==0: return math.hypot(x-x1,y-y1)
        t=((x-x1)*dx+(y-y1)*dy)/(dx*dx+dy*dy)
        t=max(0,min(1,t))
        qx=x1+t*dx; qy=y1+t*dy
        return math.hypot(x-qx,y-qy)
    def rdp(seq):
        if len(seq)<=2: return seq
        a=seq[0]; b=seq[-1]; md=-1; mi=0
        for i in range(1,len(seq)-1):
            d=dist_point_line(seq[i],a,b)
            if d>md: md=d; mi=i
        if md>epsilon:
            left=rdp(seq[:mi+1]); right=rdp(seq[mi:])
            return left[:-1]+right
        return [a,b]
    return rdp(points)

# Every visible campus destination is selectable. "anchor" is the nearest
# manually mapped path-network access point used by the prototype.
LOCATIONS={
 "chanakya":("Chanakya Block","Academic / Labs","chanakya"),
 "aryabhatta":("Aryabhatta Block","Academic / Labs","aryabhatta"),
 "bhaskara":("Bhaskara Block","Academic / Labs","bhaskara"),
 "cv_raman":("CV Raman Square","Academic / Labs","cv_raman"),
 "ai_lab":("AI Lab / Aerobotics Centre","Academic / Labs","bhaskara"),
 "mythreyi":("Mythreyi Block","Academic / Labs","mythreyi"),
 "sanskriti":("Sanskriti Auditorium","Academic / Labs","sanskriti"),

 "thiruvalluvar":("Thiruvalluvar Hostel","Hostels","thiruvalluvar"),
 "bharathi":("Bharathi Hostel","Hostels","thiruvalluvar"),
 "cheran":("Cheran Hostel","Hostels","thiruvalluvar"),
 "vivekananda":("Vivekananda Hostel","Hostels","vivekananda"),
 "onam":("Onam Hostel","Hostels","onam_access"),
 "pallavan":("Pallavan Hostel","Hostels","pallavan_access"),
 "pandian":("Pandian Hostel","Hostels","pandian_access"),
 "yamuna":("Yamuna Hostel","Hostels","yamuna"),
 "kaveri":("Kaveri Hostel","Hostels","kaveri"),
 "narmada":("Narmada Hostel","Hostels","narmada"),
 "ganga":("Ganga Hostel","Hostels","ganga"),

 "fitness_studio":("Fitness Studio","Facilities / Landmarks","fitness_studio"),
 "pavilion":("Pavilion","Facilities / Landmarks","pavilion"),
 "olive_dining":("Olive Dining","Facilities / Landmarks","pavilion"),
 "canteen":("Canteen","Facilities / Landmarks","pavilion"),
 "central_park":("Central Park","Facilities / Landmarks","central_park"),
 "oasis_pond":("Oasis Pond","Facilities / Landmarks","oasis_pond"),
 "phoenix_circle":("Phoenix Circle","Facilities / Landmarks","phoenix_circle"),
 "triad":("Triad","Facilities / Landmarks","triad"),
 "phoenix_grove":("Phoenix Circle & Grove","Facilities / Landmarks","phoenix_circle"),
 "lake_view_parking":("Lake View Parking","Facilities / Landmarks","pavilion"),
 "pavilion_parking":("Pavilion Parking","Facilities / Landmarks","pavilion"),
 "lake_view_parking":("Lake View Parking","Facilities / Landmarks","lake_view_parking"),
 "mahogany_parking":("Mahogany Parking","Facilities / Landmarks","mahogany_parking"),
 "racing_bay":("Racing Bay","Facilities / Landmarks","racing_bay"),
 "kpr_sports":("KPR Sports Complex","Facilities / Landmarks","kpr_sports"),

 "gate01":("Gate 01","Gates","gate01"),
 "gate02":("Gate 02","Gates","bhaskara"),
 "gate03":("Gate 03","Gates","gate03"),
 "gate04":("Gate 04","Gates","gate04"),
 "gate05":("Gate 05","Gates","gate05"),
 "gate07":("Gate 07","Gates","gate07"),
}

# Actual visual positions (destination pins) on the campus map.
# The route anchor is the nearest walkable path point; the pin stays on the destination itself.
POSITIONS={
 "oasis_pond":[65.0,30.3],
 "triad":[69.0,58.6],
 "lake_view_parking":[63.1,77.0],
 "pandian":[25.2,55.5],
 "onam":[25.2,46.4],
 "pallavan":[20.8,50.7],
 "vivekananda":[11.2,33.0],
 "kpr_sports":[2.8,57.8],
 "gate01":[46.9,86.5],
 "gate04":[27.9,60.9],
 "gate07":[40.4,10.4],
}


GROUPS=[
 ("Academic / Labs",[k for k,v in LOCATIONS.items() if v[1]=="Academic / Labs"]),
 ("Hostels",[k for k,v in LOCATIONS.items() if v[1]=="Hostels"]),
 ("Facilities / Landmarks",[k for k,v in LOCATIONS.items() if v[1]=="Facilities / Landmarks"]),
 ("Gates",[k for k,v in LOCATIONS.items() if v[1]=="Gates"]),
]

@app.route("/")
def index():
    return render_template("dashboard.html", locations=LOCATIONS, groups=GROUPS)

@app.get("/api/locations")
def locations():
    return jsonify([{
      "id":k,"name":v[0],"category":v[1],"anchor":v[2],"position":POSITIONS.get(k, DATA.get("anchors",{}).get(v[2]))
    } for k,v in LOCATIONS.items()])


@app.post("/api/live-route")
def live_route():
    body=request.get_json(force=True)
    end=body.get("end")
    live_position=gps_to_map_position(body.get("lat"), body.get("lon"))
    if end not in LOCATIONS:
        return jsonify(error="Invalid destination"),400
    if not live_position:
        return jsonify(error="Your live location is outside the calibrated KPRIET campus area."),400

    ea=LOCATIONS[end][2]
    end_route_position=DATA.get("anchors",{}).get(ea)
    end_position=POSITIONS.get(end, end_route_position)
    raw_points=manual_route(live_position,end_route_position)
    if not raw_points:
        return jsonify(error="No mapped red path from your live location to this destination yet."),400
    points=simplify_polyline(raw_points,1.25)
    total_px=0.0
    for a,b in zip(raw_points,raw_points[1:]):
        dx=(b[0]-a[0])*MAP_W/100.0; dy=(b[1]-a[1])*MAP_H/100.0
        total_px += math.hypot(dx,dy)
    dist=total_px*0.45
    return jsonify(
      route_points=points, distance_m=round(dist), time_min=max(1,round(dist/75)),
      start={"id":"live","name":"Live Location","position":live_position,
             "latitude":float(body.get("lat")),"longitude":float(body.get("lon")),
             "accuracy":body.get("accuracy")},
      end={"id":end,"name":LOCATIONS[end][0],"position":end_position},
      instructions=["Start from your current live location","Follow the red manually marked campus path","Stay outside green garden areas",f"Reach the mapped path access point for {LOCATIONS[end][0]}"],
      note="Live GPS is converted to the supplied campus-map coordinate system. The blue route remains constrained to the red mapped path network."
    )

@app.post("/api/route")
def route():
    body=request.get_json(force=True); start=body.get("start"); end=body.get("end")
    if start not in LOCATIONS or end not in LOCATIONS:
        return jsonify(error="Invalid location"),400
    if start==end: return jsonify(error="Start and destination must be different"),400

    sa=LOCATIONS[start][2]; ea=LOCATIONS[end][2]

    # IMPORTANT: route using the mapped PATH ACCESS POINTS, not the visual
    # building labels.  A building pin may sit away from the red walkable
    # network; routing directly to that pin can cut across gardens/buildings.
    # The blue line therefore ends at the nearest mapped red-network anchor,
    # while the S/D pins remain on the actual selected locations.
    start_route_position=DATA.get("anchors",{}).get(sa)
    end_route_position=DATA.get("anchors",{}).get(ea)
    start_position=POSITIONS.get(start, start_route_position)
    end_position=POSITIONS.get(end, end_route_position)

    raw_points=manual_route(start_route_position,end_route_position)
    if not raw_points:
        return jsonify(error="No mapped red path between these locations yet."),400
    points=simplify_polyline(raw_points,1.25)
    # Estimate distance from the actual red-network polyline.
    total_px=0.0
    for a,b in zip(raw_points,raw_points[1:]):
        dx=(b[0]-a[0])*MAP_W/100.0; dy=(b[1]-a[1])*MAP_H/100.0
        total_px += math.hypot(dx,dy)
    dist=total_px*0.45
    same_anchor=(sa==ea)
    note="Blue route is constrained to the red manually marked campus path network. Green garden areas are never used."
    instructions=[f"Start at {LOCATIONS[start][0]}",
      "Follow the red manually marked campus path",
      "Stay outside green garden areas",
      f"Reach the mapped path access point for {LOCATIONS[end][0]}"]
    return jsonify(route_points=points,distance_m=round(dist),time_min=max(1,round(dist/75)),
      start={"id":start,"name":LOCATIONS[start][0],"position":start_position},
      end={"id":end,"name":LOCATIONS[end][0],"position":end_position},
      instructions=instructions,note=note,same_anchor=same_anchor)

if __name__=="__main__": app.run(debug=True)
