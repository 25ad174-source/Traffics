# CAMPUS NAV — 3D Integrated Campus Navigation

A Flask prototype for AI Integrated Campus / KPRIET campus navigation.

## Features
- CAMPUS NAV dashboard UI
- Existing path-aware routing constrained to the manually marked red path network
- Campus locations, hostels, gates, facilities and landmarks
- Interactive 3D campus visualization using Three.js
- 3D orbit/zoom controls
- Extruded campus buildings/landmarks
- 3D start and destination pins
- Blue navigation route elevated above the campus map
- 2D/3D view switch

## Run
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

The 3D renderer uses Three.js via its browser ES-module CDN. Three.js provides WebGL-based rendering and OrbitControls for interactive camera movement. See the official Three.js documentation for WebGLRenderer and setup guidance.


## Live Navigation Demo

The 3D view now supports a live-navigation prototype. Select From/To and press **Start Live Navigation**. The blue user marker moves continuously along the mapped path, the 3D camera follows it, and the remaining distance/ETA update in real time. Use 1× walking or accelerated demo speeds (2×/4×/8×). Pause, resume, or stop the navigation.

This is a **simulated live navigation prototype**, not GPS positioning. It follows the campus route returned by the Flask routing API. Real GPS navigation would require campus latitude/longitude calibration and device geolocation integration.

## Live GPS starting location
The **📍 Live Location** button beside **FROM / Where are you?** uses the browser Geolocation API. After the user grants permission, the app watches the device position and updates the starting point and route. The current GPS position is mapped to the supplied campus image using a prototype georeference centered on KPRIET. For production use, replace the calibration with surveyed campus control points for higher accuracy.

When running on `http://127.0.0.1:5000`, Chrome can request location permission for the local app. The browser must have Location enabled.


### Live Location option
The FROM dropdown now includes **📍 Live Location (GPS)** as a normal selectable option. Selecting it requests browser location permission and continuously updates the starting position using the Geolocation API.
