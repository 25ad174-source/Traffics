import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

let renderer, scene, camera, controls, ground, routeObject, startObject, endObject, liveObject;
let routePoints=[];
let routeCenter=new THREE.Vector3();
let routeRadius=45;
let autoRotateUser=false;
let livePoints=[], liveCum=[], liveTotal=0, liveDistanceM=0, liveDurationMs=0, liveStartTime=0, livePaused=false, livePausedAt=0, liveRaf=0, liveRunning=false, liveCurrentFraction=0;
let initialized = false;
const W=1491, H=1055;
const WORLD_W=100, WORLD_H=100*H/W;
const buildings=[
  ['Aryabhatta Block',53.991,9.858,13,8,5,'academic'],
  ['Bhaskara Block',66.801,8.531,10,8,4,'academic'],
  ['CV Raman Square',53.991,23.697,11,8,2,'square'],
  ['Chanakya Block',63.984,39.052,12,10,6,'academic'],
  ['Mythreyi Block',77.062,41.896,10,9,5,'academic'],
  ['Thiruvalluvar Hostel',27.632,21.801,13,10,4,'hostel'],
  ['Vivekananda Hostel',16.1,33.18,10,9,3,'hostel'],
  ['Onam Hostel',28.5,46.5,7,6,3,'hostel'],
  ['Pallavan Hostel',16.8,48,7,6,3,'hostel'],
  ['Pandian Hostel',28.5,55.55,7,6,3,'hostel'],
  ['Central Park',75.117,25.592,16,12,0.7,'park'],
  ['Oasis Pond',62.173,33.365,6,6,0.8,'water'],
  ['Phoenix Circle',56.338,61.611,8,8,1,'park'],
  ['Triad',66.667,59.052,7,7,1,'landmark'],
  ['KPR Sports Complex',2.8,57.8,9,8,3,'sports'],
  ['Mahogany Parking',84,14,9,7,1.2,'parking'],
  ['Racing Bay',79,20,7,6,1.4,'parking'],
  ['Yamuna Hostel',87.7,31.5,9,9,4,'hostel'],
  ['Kaveri Hostel',87.7,40,9,8,4,'hostel'],
  ['Narmada Hostel',95,40,8,8,4,'hostel'],
  ['Ganga Hostel',91,16.5,8,8,4,'hostel']
];

function xy(px,py,y=0){
  return new THREE.Vector3((px-50)*(WORLD_W/100), y, (py-50)*(WORLD_H/100));
}
function labelSprite(text,color='#0b2a56'){
  const c=document.createElement('canvas'); c.width=512; c.height=96;
  const ctx=c.getContext('2d');
  ctx.fillStyle='rgba(255,255,255,.92)'; ctx.roundRect(6,6,500,84,18); ctx.fill();
  ctx.strokeStyle='rgba(11,42,86,.18)'; ctx.stroke();
  ctx.fillStyle=color; ctx.font='700 28px Arial'; ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText(text,256,48);
  const tex=new THREE.CanvasTexture(c); tex.colorSpace=THREE.SRGBColorSpace;
  const mat=new THREE.SpriteMaterial({map:tex,transparent:true,depthTest:false});
  const sp=new THREE.Sprite(mat); sp.scale.set(11,2.1,1); return sp;
}
function matFor(kind){
  const map={academic:0x9bbbe7,hostel:0xd8b59d,square:0x93a6c4,park:0x69a77a,water:0x4ea5d1,landmark:0xe3a94d,sports:0xb3c1d4,parking:0x8d8d8d};
  return new THREE.MeshStandardMaterial({color:map[kind]||0xaab7c8,roughness:.82,metalness:.04,transparent:kind==='park'||kind==='water',opacity:kind==='park'?0.78:kind==='water'?0.9:1});
}
function makeBuildings(){
  buildings.forEach(([name,x,z,w,d,h,kind])=>{
    const g=new THREE.BoxGeometry(w,h,d);
    const m=new THREE.Mesh(g,matFor(kind));
    const p=xy(x,z,h/2); m.position.copy(p); m.castShadow=true; m.receiveShadow=true; m.userData.name=name; scene.add(m);
    if(kind==='academic'||kind==='hostel'||kind==='sports'){
      const roof=new THREE.Mesh(new THREE.BoxGeometry(w*0.86,0.5,d*0.86),new THREE.MeshStandardMaterial({color:0x355b88,roughness:.7}));
      roof.position.set(p.x,h+0.25,p.z); scene.add(roof);
    }
    const label=labelSprite(name); label.position.set(p.x,h+2.4,p.z); scene.add(label);
  });
}
function makeGround(){
  const tex=new THREE.TextureLoader().load('/static/images/campus-map.png');
  tex.colorSpace=THREE.SRGBColorSpace; tex.anisotropy=renderer.capabilities.getMaxAnisotropy();
  const geo=new THREE.PlaneGeometry(WORLD_W,WORLD_H);
  const mat=new THREE.MeshStandardMaterial({map:tex,roughness:1,metalness:0});
  ground=new THREE.Mesh(geo,mat); ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground);
}
function marker(color,label){
  const group=new THREE.Group();
  const pin=new THREE.Mesh(new THREE.CylinderGeometry(.75,.75,.3,32),new THREE.MeshStandardMaterial({color}));
  pin.rotation.x=Math.PI/2; group.add(pin);
  const ball=new THREE.Mesh(new THREE.SphereGeometry(1.1,20,20),new THREE.MeshStandardMaterial({color,emissive:color,emissiveIntensity:.15})); ball.position.y=1.1; group.add(ball);
  const text=labelSprite(label,color===0xef4038?'#b72d28':'#0a67dd'); text.position.y=3.3; text.scale.set(6,1.3,1); group.add(text);
  return group;
}
function drawRoute(points){
  if(routeObject) scene.remove(routeObject);
  routePoints=Array.isArray(points)?points:[];
  if(!routePoints||routePoints.length<2) return;
  const verts=[];
  routePoints.forEach(([x,y])=>{ const p=xy(x,y,1.55); verts.push(p.x,p.y,p.z); });
  const geom=new THREE.BufferGeometry(); geom.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));
  const mat=new THREE.LineBasicMaterial({color:0x0876f9,linewidth:5});
  routeObject=new THREE.Line(geom,mat); scene.add(routeObject);
  const dots=new THREE.Group();
  const step=Math.max(1,Math.floor(routePoints.length/30));
  routePoints.filter((_,i)=>i%step===0).forEach(([x,y])=>{
    const d=new THREE.Mesh(new THREE.SphereGeometry(.35,10,10),new THREE.MeshBasicMaterial({color:0x74b6ff}));
    d.position.copy(xy(x,y,1.62)); dots.add(d);
  });
  routeObject.add(dots);
}
function calculateRouteView(points){
  if(!points||points.length<2) return;
  const box=new THREE.Box3();
  points.forEach(([x,y])=>box.expandByPoint(xy(x,y,0)));
  box.getCenter(routeCenter);
  const size=box.getSize(new THREE.Vector3());
  routeRadius=Math.max(18, Math.max(size.x,size.z)*0.62);
}
function focusRoute(animated=true){
  if(!controls||!routePoints||routePoints.length<2) return;
  calculateRouteView(routePoints);
  const target=routeCenter.clone();
  const currentDir=camera.position.clone().sub(controls.target);
  if(currentDir.lengthSq()<1) currentDir.set(1,.9,1);
  currentDir.normalize();
  const distance=Math.max(34, Math.min(105, routeRadius*1.55));
  const desired=target.clone().add(currentDir.multiplyScalar(distance));
  desired.y=Math.max(24, Math.min(72, distance*.72));
  controls.autoRotate=false;
  if(animated){
    const fromPos=camera.position.clone(), fromTarget=controls.target.clone();
    const start=performance.now(), duration=650;
    function step(now){
      const u=Math.min(1,(now-start)/duration), e=1-Math.pow(1-u,3);
      camera.position.lerpVectors(fromPos,desired,e);
      controls.target.lerpVectors(fromTarget,target,e);
      controls.update();
      if(u<1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }else{
    camera.position.copy(desired); controls.target.copy(target); controls.update();
  }
}
function setAutoRotate(enabled){
  autoRotateUser=!!enabled;
  if(controls){
    controls.autoRotate=autoRotateUser && !liveRunning;
    controls.autoRotateSpeed=0.65;
    controls.update();
  }
  window.dispatchEvent(new CustomEvent('campus-3d-rotate',{detail:{enabled:autoRotateUser}}));
}
function createLiveObject(){
  if(liveObject) scene.remove(liveObject);
  liveObject=new THREE.Group();
  const halo=new THREE.Mesh(new THREE.RingGeometry(1.3,1.8,32),new THREE.MeshBasicMaterial({color:0x0876f9,transparent:true,opacity:.28,side:THREE.DoubleSide}));
  halo.rotation.x=-Math.PI/2; halo.position.y=.08; liveObject.add(halo);
  const body=new THREE.Mesh(new THREE.SphereGeometry(1.15,20,20),new THREE.MeshStandardMaterial({color:0x0876f9,emissive:0x0876f9,emissiveIntensity:.32}));
  body.position.y=1.15; body.castShadow=true; liveObject.add(body);
  const arrow=new THREE.Mesh(new THREE.ConeGeometry(.48,1.25,4),new THREE.MeshStandardMaterial({color:0xffffff,emissive:0x9ccaff,emissiveIntensity:.3}));
  arrow.rotation.z=-Math.PI/2; arrow.position.set(0,1.2,0); liveObject.add(arrow);
  const label=labelSprite('YOU ARE HERE','#0a67dd'); label.position.y=3.1; label.scale.set(6.5,1.25,1); liveObject.add(label);
  scene.add(liveObject);
}
function prepareLivePath(points,distanceM,timeMin){
  livePoints=points||[]; liveCum=[0];
  for(let i=1;i<livePoints.length;i++){
    const a=livePoints[i-1],b=livePoints[i];
    const dx=b[0]-a[0], dy=b[1]-a[1];
    liveCum.push(liveCum[i-1]+Math.hypot(dx,dy));
  }
  liveTotal=liveCum[liveCum.length-1]||0;
  liveDistanceM=Math.max(1,Number(distanceM)||1);
  liveDurationMs=Math.max(8000,(Number(timeMin)||1)*60000);
  createLiveObject();
}
function pointAtFraction(t){
  if(!livePoints.length) return null;
  if(livePoints.length===1) return livePoints[0];
  const target=Math.max(0,Math.min(1,t))*liveTotal;
  let lo=0,hi=liveCum.length-1;
  while(lo<hi){const mid=(lo+hi)>>1; if(liveCum[mid]<target) lo=mid+1; else hi=mid;}
  const i=Math.max(1,lo), prev=liveCum[i-1], seg=Math.max(1e-9,liveCum[i]-prev), u=(target-prev)/seg;
  const a=livePoints[i-1],b=livePoints[i];
  return [a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u];
}
function setLiveProgress(fraction){
  if(!liveObject) return;
  const p=pointAtFraction(fraction); if(!p) return;
  const wp=xy(p[0],p[1],0); liveObject.position.set(wp.x,0,wp.z);
  const p2=pointAtFraction(Math.min(1,fraction+.002))||p;
  const w2=xy(p2[0],p2[1],0); liveObject.rotation.y=Math.atan2(w2.x-wp.x,w2.z-wp.z);
  const scale=1+0.10*Math.sin(performance.now()/180); liveObject.children[0].scale.set(scale,scale,scale);
  if(controls && liveRunning){
    const next=xy(p2[0],p2[1],0);
    const dir=new THREE.Vector3(next.x-wp.x,0,next.z-wp.z);
    if(dir.lengthSq()<0.0001) dir.set(0,0,1);
    dir.normalize();
    const behind=dir.clone().multiplyScalar(-20);
    const side=new THREE.Vector3(-dir.z,0,dir.x).multiplyScalar(7);
    const desired=new THREE.Vector3(wp.x+behind.x+side.x,20,wp.z+behind.z+side.z);
    const target=new THREE.Vector3(wp.x+dir.x*8,2.5,wp.z+dir.z*8);
    controls.target.lerp(target,.14);
    camera.position.lerp(desired,.08);
    controls.update();
  }
}
function emitLiveState(fraction,finished=false){
  liveCurrentFraction=fraction;
  const elapsedMin=Math.max(0,(fraction*(liveDurationMs/60000)));
  const remainingM=Math.max(0,Math.round(liveDistanceM*(1-fraction)));
  const remainingMin=Math.max(0,(liveDurationMs*(1-fraction))/60000);
  window.dispatchEvent(new CustomEvent('campus-live-progress',{detail:{fraction,elapsedMin,remainingM,remainingMin,finished,paused:livePaused}}));
}
function animateLive(now){
  if(!liveRunning) return;
  const elapsed=Math.max(0,now-liveStartTime);
  const fraction=Math.min(1,elapsed/liveDurationMs);
  setLiveProgress(fraction); emitLiveState(fraction,false);
  if(fraction>=1){
    liveRunning=false; livePaused=false; livePausedAt=0; setLiveProgress(1); controls.autoRotate=autoRotateUser; emitLiveState(1,true); return;
  }
  liveRaf=requestAnimationFrame(animateLive);
}
export function startLiveNavigation(opts={}){
  init();
  if(!livePoints.length) return false;
  const speed=Math.max(.1,Number(opts.speed)||1);
  // Speed multiplier: 1x follows the calculated walking time; higher values are demo acceleration.
  liveDurationMs=Math.max(8000,(Number(opts.timeMin)||1)*60000/speed);
  livePaused=false; liveRunning=true; controls.autoRotate=false; liveStartTime=performance.now(); livePausedAt=0; liveCurrentFraction=0;
  setLiveProgress(0); emitLiveState(0,false);
  cancelAnimationFrame(liveRaf); liveRaf=requestAnimationFrame(animateLive);
  return true;
}
export function pauseLiveNavigation(){
  if(!liveRunning) return;
  liveRunning=false; livePaused=true; livePausedAt=performance.now(); cancelAnimationFrame(liveRaf); emitLiveState(liveCurrentFraction,false);
}
export function resumeLiveNavigation(){
  if(!livePaused) return;
  const pausedFor=Math.max(0,performance.now()-livePausedAt);
  liveStartTime+=pausedFor; livePaused=false; liveRunning=true; liveRaf=requestAnimationFrame(animateLive); emitLiveState(Math.min(1,(performance.now()-liveStartTime)/liveDurationMs),false);
}
export function stopLiveNavigation(){
  liveRunning=false; livePaused=false; livePausedAt=0; liveCurrentFraction=0; cancelAnimationFrame(liveRaf); controls && (controls.autoRotate=autoRotateUser);
  if(liveObject){scene.remove(liveObject);liveObject=null;}
  emitLiveState(0,false);
}
function setMarkers(start,end){
  if(startObject) scene.remove(startObject); if(endObject) scene.remove(endObject);
  if(start?.position){startObject=marker(0x0876f9,'START'); startObject.position.copy(xy(start.position[0],start.position[1],0)); scene.add(startObject);}
  if(end?.position){endObject=marker(0xef4038,'DESTINATION'); endObject.position.copy(xy(end.position[0],end.position[1],0)); scene.add(endObject);}
}
function init(){
  if(initialized) return; initialized=true;
  const canvas=document.getElementById('threeCanvas');
  if(!canvas) throw new Error('3D canvas was not found');
  const rect=canvas.getBoundingClientRect();
  const cw=Math.max(1,Math.floor(rect.width||canvas.parentElement?.clientWidth||800));
  const ch=Math.max(1,Math.floor(rect.height||canvas.parentElement?.clientHeight||450));
  renderer=new THREE.WebGLRenderer({canvas,antialias:true}); renderer.setPixelRatio(Math.min(2,window.devicePixelRatio||1)); renderer.setSize(cw,ch,false); renderer.shadowMap.enabled=true; renderer.outputColorSpace=THREE.SRGBColorSpace;
  scene=new THREE.Scene(); scene.background=new THREE.Color(0xdce8f4);
  camera=new THREE.PerspectiveCamera(48,cw/ch,.1,500); camera.position.set(70,70,75);
  controls=new OrbitControls(camera,canvas); controls.enableDamping=true; controls.enableRotate=true; controls.enableZoom=true; controls.enablePan=true; controls.zoomSpeed=1.15; controls.rotateSpeed=.8; controls.target.set(0,0,0); controls.minDistance=18; controls.maxDistance=170; controls.maxPolarAngle=Math.PI/2.03; controls.autoRotate=false; controls.autoRotateSpeed=.65;
  scene.add(new THREE.HemisphereLight(0xffffff,0x7892aa,2.1));
  const sun=new THREE.DirectionalLight(0xffffff,2.5); sun.position.set(40,90,30); sun.castShadow=true; scene.add(sun);
  makeGround(); makeBuildings();
  const grid=new THREE.GridHelper(100,20,0x8ca2b8,0xb9c8d7); grid.position.y=.03; grid.material.transparent=true; grid.material.opacity=.14; scene.add(grid);
  window.addEventListener('resize',resize3D);
  animate();
}
function resize3D(){ if(!renderer||!camera)return; const canvas=document.getElementById('threeCanvas'); if(!canvas)return; const rect=canvas.getBoundingClientRect(); const w=Math.max(1,Math.floor(rect.width)); const h=Math.max(1,Math.floor(rect.height)); renderer.setSize(w,h,false); camera.aspect=w/h; camera.updateProjectionMatrix(); }
function animate(){ requestAnimationFrame(animate); controls?.update(); renderer?.render(scene,camera); }
export function updateRoute3D(data){
  init();
  stopLiveNavigation();
  const points=data?.route_points||[];
  drawRoute(points);
  setMarkers(data?.start,data?.end);
  prepareLivePath(points,data?.distance_m,data?.time_min);
  if(points.length>1){ calculateRouteView(points); focusRoute(false); autoRotateUser=true; controls.autoRotate=true; controls.autoRotateSpeed=.55; }
  setLiveProgress(0);
}
export function focusRoute3D(){ init(); focusRoute(true); }
export function toggleAutoRotate3D(){ init(); setAutoRotate(!autoRotateUser); return autoRotateUser; }
export function reset3D(){ init(); stopLiveNavigation(); autoRotateUser=false; controls.autoRotate=false; camera.position.set(70,70,75); controls.target.set(0,0,0); controls.update(); renderer.render(scene,camera); }
