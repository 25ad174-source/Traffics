import { updateRoute3D, reset3D, focusRoute3D, toggleAutoRotate3D, startLiveNavigation, pauseLiveNavigation, resumeLiveNavigation, stopLiveNavigation } from './three.js';
window.Campus3D={updateRoute3D,reset3D,focusRoute3D,toggleAutoRotate3D,startLiveNavigation,pauseLiveNavigation,resumeLiveNavigation,stopLiveNavigation};
