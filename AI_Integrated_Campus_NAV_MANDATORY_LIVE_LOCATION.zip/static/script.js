const start=document.getElementById('start');
const end=document.getElementById('end');
// Backwards-compatible selectors are created from the navigation controls in this redesigned UI.
const line=document.getElementById('route');
const sp=document.getElementById('s');
const dp=document.getElementById('d');
const layer=document.getElementById('manualLayer');
const manualButton=document.getElementById('manualToggle');
const titleDest=document.getElementById('destName');
const categoryDest=document.getElementById('destCategory');
const time=document.getElementById('time');
const dist=document.getElementById('dist');
const steps=document.getElementById('steps');
const search=document.getElementById('search');
const results=document.getElementById('searchResults');
const categoryFilter=document.getElementById('categoryFilter');
const fromVisible=document.getElementById('fromVisible');
const toVisible=document.getElementById('toVisible');
let requestNo=0, allLocations=[], zoom=1, mapMode='3d', liveActive=false, livePaused=false;
let liveWatchId=null, liveGpsActive=false, lastLiveRouteAt=0, lastLiveMapPosition=null;

let threeLoadError=null;
async function load3D(){
  if(window.Campus3D) return window.Campus3D;
  try{
    const mod=await import('/static/three-bridge.js');
    return window.Campus3D||mod;
  }catch(e){
    threeLoadError=e;
    console.error('CAMPUS NAV 3D failed to load:',e);
    const hud=document.querySelector('.three-hud');
    if(hud) hud.innerHTML='<span>3D CAMPUS</span><small>3D engine could not load. Check internet/CDN access.</small>';
    return null;
  }
}
function setMapMode(mode){ mapMode=mode; const stage=document.getElementById('navigator'); stage.classList.toggle('mode-3d',mode==='3d'); stage.classList.toggle('mode-2d',mode==='2d'); document.getElementById('view3d')?.classList.toggle('active',mode==='3d'); document.getElementById('view2d')?.classList.toggle('active',mode==='2d'); if(mode==='3d'){ load3D().then(()=>window.Campus3D?.updateRoute3D(window.__lastRoute||null)); } }
function reset3DView(){ if(window.Campus3D?.reset3D) window.Campus3D.reset3D(); const b=document.getElementById('rotate3DBtn'); if(b)b.classList.remove('active'); }
async function focus3DRoute(){ const api=await load3D(); api?.focusRoute3D?.(); }
async function toggle3DRotation(){ const api=await load3D(); const on=api?.toggleAutoRotate3D?.(); const b=document.getElementById('rotate3DBtn'); if(b)b.classList.toggle('active',!!on); }
window.setMapMode=setMapMode; window.reset3DView=reset3DView; window.focus3DRoute=focus3DRoute; window.toggle3DRotation=toggle3DRotation;

const startSel={value:'__live__'};
const endSel=toVisible;

function pin(el,p){
  if(!p||p.length<2)return;
  el.style.left=`calc(${p[0]}% - 15px)`;
  el.style.top=`calc(${p[1]}% - 15px)`;
  el.style.display='grid';
}
function showManual(){ layer.classList.add('show'); manualButton.classList.add('active'); }
function toggleManualFromUI(){ layer.classList.toggle('show'); manualButton.classList.toggle('active'); }
function focusNavigator(group){
  document.getElementById('navigator').scrollIntoView({behavior:'smooth',block:'center'});
  if(group && categoryFilter) categoryFilter.value=group;
}
function quickCategory(group){ categoryFilter.value=group; focusNavigator(); }
function clearRoute(){ line.setAttribute('points',''); sp.style.display='none'; dp.style.display='none'; }
function zoomMap(delta){ zoom=Math.max(1,Math.min(1.8,zoom+delta*.1)); document.querySelector('.map-image').style.transform=`scale(${zoom})`; layer.style.transform=`scale(${zoom})`; line.style.transformOrigin='50% 50%'; }
function resetMap(){ zoom=1; document.querySelector('.map-image').style.transform='scale(1)'; layer.style.transform='scale(1)'; }

function setDestination(id){
  endSel.value=id;
  calculate(false);
  document.getElementById('navigator').scrollIntoView({behavior:'smooth',block:'center'});
}
function setStart(id){ useLiveLocation(); }

function setLocationStatus(message, active=false){
  const el=document.getElementById('locationStatus');
  if(el) el.textContent=message;
  const b=document.getElementById('liveLocationBtn');
  if(b){
    b.classList.toggle('active',active);
    b.textContent=active?'✓ GPS Active':'Enable GPS';
  }
  const startBtn=document.getElementById('startLiveBtn');
  if(startBtn) startBtn.disabled=!active;
}

function stopLiveLocationWatch(){
  if(liveWatchId!==null && navigator.geolocation){ navigator.geolocation.clearWatch(liveWatchId); }
  liveWatchId=null; liveGpsActive=false;
  setLocationStatus('Live Location is mandatory. Enable GPS to choose a route.',false);
}

async function routeFromLiveGPS(position, showError=false){
  const now=Date.now();
  const c=position.coords;
  if(now-lastLiveRouteAt<1200 && lastLiveMapPosition) return;
  lastLiveRouteAt=now;
  try{
    const r=await fetch('/api/live-route',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
      lat:c.latitude,lon:c.longitude,accuracy:c.accuracy,end:endSel.value
    })});
    const d=await r.json();
    if(!r.ok){ if(showError) alert(d.error||'Could not map your live location to the campus path.'); return; }
    window.__lastRoute=d;
    lastLiveMapPosition=d.start.position;
    line.setAttribute('points',d.route_points.map(p=>p.join(',')).join(' '));
    titleDest.textContent=d.end.name;
    categoryDest.textContent=(allLocations.find(x=>x.id===d.end.id)?.category||'Campus')+' · Campus';
    dist.textContent=`Approx. ${d.distance_m} m`;
    time.textContent=`${d.time_min} min walk`;
    steps.innerHTML=d.instructions.map(x=>`<li>${x}</li>`).join('');
    pin(sp,d.start.position);
    pin(dp,d.end.position||d.route_points[d.route_points.length-1]);
    const acc=Math.round(c.accuracy||0);
    setLocationStatus(`GPS active · accuracy ±${acc} m · Live Location is your starting point`,true);
    if(mapMode==='3d'){ await load3D(); window.Campus3D?.updateRoute3D(d); }
  }catch(err){ if(showError) alert('Could not read your live location. Check browser location permission.'); }
}

function useLiveLocation(){
  if(liveGpsActive) return;
  if(!navigator.geolocation){
    alert('This browser does not support device location.');
    return;
  }
  setLocationStatus('Requesting device location permission…',false);
  const options={enableHighAccuracy:true,maximumAge:3000,timeout:15000};
  liveWatchId=navigator.geolocation.watchPosition(
    pos=>{
      liveGpsActive=true;
      routeFromLiveGPS(pos,true);
    },
    err=>{
      stopLiveLocationWatch();
      const msg=err.code===1?'Location permission denied. Allow Location for http://127.0.0.1:5000 and try again.':err.code===2?'Your device could not determine a location.':'Location request timed out.';
      setLocationStatus(msg,false);
      alert(msg);
    }, options
  );
}

async function calculate(showError=true){
  if(!liveGpsActive){ if(showError) setLocationStatus('Live Location is mandatory. Click Enable GPS first.',false); return; }
  try{
    if(navigator.geolocation){ navigator.geolocation.getCurrentPosition(pos=>routeFromLiveGPS(pos,showError),()=>{}, {enableHighAccuracy:true,maximumAge:3000,timeout:10000}); }
  }catch(e){}
  return;
  const myRequest=++requestNo;
  try{
    const r=await fetch('/api/route',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({start:startSel.value,end:endSel.value})});
    const d=await r.json();
    if(myRequest!==requestNo)return;
    if(!r.ok){ if(showError) alert(d.error||'No mapped path between these locations yet.'); return; }
    window.Campus3D?.stopLiveNavigation?.();
    setLiveUI(false,false);
    window.__lastRoute=d;
    line.setAttribute('points',d.route_points.map(p=>p.join(',')).join(' '));
    titleDest.textContent=d.end.name;
    categoryDest.textContent=(allLocations.find(x=>x.id===d.end.id)?.category||'Campus')+' · Campus';
    dist.textContent=`Approx. ${d.distance_m} m`;
    time.textContent=`${d.time_min} min walk`;
    steps.innerHTML=d.instructions.map(x=>`<li>${x}</li>`).join('');
    pin(sp,d.start.position||d.route_points[0]);
    pin(dp,d.end.position||d.route_points[d.route_points.length-1]);
    if(mapMode==='3d'){ await load3D(); window.Campus3D?.updateRoute3D(d); }
  }catch(err){ if(myRequest===requestNo&&showError) alert('Could not calculate the route. Make sure the Flask server is running.'); }
}

async function startLiveNavigation(){
  const api=await load3D();
  if(!api?.startLiveNavigation){alert('3D live navigation is not available.');return;}
  if(!window.__lastRoute){await calculate(false);}
  const route=window.__lastRoute;
  if(!route){alert('Select a valid start and destination first.');return;}
  const speed=Number(document.getElementById('liveSpeed')?.value||4);
  const ok=api.startLiveNavigation({timeMin:route.time_min,speed});
  if(ok){setLiveUI(true,false);}
}
function toggleLivePause(){
  const api=window.Campus3D; if(!api)return;
  if(livePaused){api.resumeLiveNavigation();setLiveUI(true,false);}
  else {api.pauseLiveNavigation();setLiveUI(true,true);}
}
function stopLiveNavigation(){
  window.Campus3D?.stopLiveNavigation?.();
  setLiveUI(false,false);
  const bar=document.getElementById('liveProgress'); if(bar)bar.style.width='0%';
  const rem=document.getElementById('liveRemaining'); if(rem)rem.textContent='Remaining —';
  const eta=document.getElementById('liveEta'); if(eta)eta.textContent='ETA —';
}
function setLiveUI(active,paused){
  liveActive=active; livePaused=paused;
  const b=document.getElementById('startLiveBtn'), p=document.getElementById('pauseLiveBtn'), st=document.getElementById('stopLiveBtn');
  if(b){b.disabled=active;b.innerHTML=active?'<span>●</span> Live Navigation Running':'<span>➤</span> Start Live Navigation';}
  if(p){p.disabled=!active;p.textContent=paused?'Resume':'Pause';}
  if(st)st.disabled=!active;
  const status=document.getElementById('liveStatus'), sub=document.getElementById('liveSubstatus');
  if(status)status.textContent=paused?'Navigation paused':active?'Live navigation in progress':'Ready for live demo';
  if(sub)sub.textContent=paused?'Press Resume to continue':'Simulated live movement along the mapped path';
}
window.startLiveNavigation=startLiveNavigation; window.toggleLivePause=toggleLivePause; window.stopLiveNavigation=stopLiveNavigation;
window.addEventListener('campus-live-progress',e=>{
  const d=e.detail||{}, pct=Math.max(0,Math.min(100,(d.fraction||0)*100));
  const bar=document.getElementById('liveProgress'); if(bar)bar.style.width=pct+'%';
  const rem=document.getElementById('liveRemaining'); if(rem)rem.textContent=d.finished?'Arrived at destination':`Remaining ${Math.round(d.remainingM||0)} m`;
  const eta=document.getElementById('liveEta'); if(eta)eta.textContent=d.finished?'ETA 0 min':`ETA ${Math.max(0,(d.remainingMin||0)).toFixed(1)} min`;
  if(d.finished){setLiveUI(false,false); const st=document.getElementById('liveStatus'); if(st)st.textContent='Arrived at destination'; const sub=document.getElementById('liveSubstatus'); if(sub)sub.textContent='Live demo completed on the mapped path';}
});

function buildSearch(){
  const q=search.value.trim().toLowerCase();
  if(!q){results.style.display='none';results.innerHTML='';return;}
  const matches=allLocations.filter(x=>x.name.toLowerCase().includes(q)).slice(0,7);
  results.innerHTML=matches.length?matches.map(x=>`<button onclick="setDestination('${x.id}');closeSearch()"><strong>${x.name}</strong><br><small>${x.category}</small></button>`).join(''):`<div style="padding:14px;color:#687692">No campus location found.</div>`;
  results.style.display='block';
}
function closeSearch(){results.style.display='none';search.value='';}
search.addEventListener('input',buildSearch);
document.addEventListener('click',e=>{if(!e.target.closest('.search-wrap'))closeSearch();});

toVisible.addEventListener('change',()=>{ if(liveGpsActive){ navigator.geolocation?.getCurrentPosition(pos=>routeFromLiveGPS(pos,true),()=>{}, {enableHighAccuracy:true,maximumAge:3000,timeout:10000}); } else setLocationStatus('Live Location is mandatory. Click Enable GPS first.',false); });
fetch('/api/locations').then(r=>r.json()).then(data=>{allLocations=data; useLiveLocation();}).catch(()=>useLiveLocation());
// Start the 3D renderer immediately when the dashboard opens.
requestAnimationFrame(()=>{ if(mapMode==='3d') load3D().then(api=>api?.updateRoute3D(window.__lastRoute||null)); });
